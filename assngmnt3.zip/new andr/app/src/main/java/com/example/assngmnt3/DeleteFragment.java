package com.example.assngmnt3;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class DeleteFragment extends Fragment {
    EditText edtfirstName,edtlastName,edtmarks,id;
    ListView course;
    RadioGroup credit;
    RadioButton one,two,three,four;
    Button delete,showData;
    DataBaseHelper dbh;


    public DeleteFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_delete, container, false);

        edtfirstName=v.findViewById(R.id.edtFirstNameDelete);
        edtlastName=v.findViewById(R.id.edtLastNameDelete);
        edtmarks=v.findViewById(R.id.edtMarksDelete);
        id=v.findViewById(R.id.edtIdDelete);
        course=v.findViewById(R.id.lvCourseDelete);
        credit=v.findViewById(R.id.rgCreditDelete);
        one=v.findViewById(R.id.rbOneDelete);
        two=v.findViewById(R.id.rbTwoDelete);
        three=v.findViewById(R.id.rbThreeDelete);
        four=v.findViewById(R.id.rbFourDelete);
        delete=v.findViewById(R.id.btnDelete);
        showData=v.findViewById(R.id.btnShowDelete);
        dbh = new DataBaseHelper(getActivity());

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int countDeleteRow=dbh.deleteRecord(Integer.parseInt(id.getText().toString()));

                if (countDeleteRow>0)
                    Toast.makeText(getContext(),"Record deleted successfully",Toast.LENGTH_LONG).show();
                if (countDeleteRow==0)
                    Toast.makeText(getContext(),"Error: Record not exists ",Toast.LENGTH_LONG).show();
            }
        });






        return v;
    }

}
