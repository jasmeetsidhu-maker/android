package com.example.assngmnt3;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class UpdateFragment extends Fragment {
    EditText edtfirstName,edtlastName,edtmarks,id;
    ListView course;
    RadioGroup credit;
    RadioButton one,two,three,four;
    Button update;
    DataBaseHelper dbh;


    public UpdateFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_update, container, false);
        edtfirstName=v.findViewById(R.id.edtFirstNameUpdate);
        edtlastName=v.findViewById(R.id.edtLastNameUpdate);
        edtmarks=v.findViewById(R.id.edtMarksUpdate);
        id=v.findViewById(R.id.edtUpdate);
        course=v.findViewById(R.id.lvCourseUpdate);
        credit=v.findViewById(R.id.rgCredirUpdate);
        one=v.findViewById(R.id.rbOneUpdate);
        two=v.findViewById(R.id.rbTwoUpdate);
        three=v.findViewById(R.id.rbThreeUpdate);
        four=v.findViewById(R.id.rbFourUpdate);
        update=v.findViewById(R.id.btnUpdate);
        dbh = new DataBaseHelper(getActivity());

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (id.getText().toString().length()==0){

                    Toast.makeText(getActivity(),"Error please enter ID", Toast.LENGTH_LONG).show();
                }
                else {
                    Grade objGrade = new Grade();
                    objGrade.setStudentId( Integer.parseInt( id.getText().toString()));
                    objGrade.setFirstName(edtfirstName.getText().toString());
                    objGrade.setLastName(edtlastName.getText().toString());
                    objGrade.setMarks( Integer.parseInt( edtmarks.getText().toString()));
                    int numOfRows = dbh.updateGrade(objGrade);
                    if (numOfRows>0){
                        Toast.makeText(getActivity(),"Successfully updated",Toast.LENGTH_LONG).show();
                    }
                    else {
                        Toast.makeText(getActivity(),"there is no existing for this ID available",Toast.LENGTH_LONG).show();
                    }

                }
            }
        });
        return v;
    }

}
