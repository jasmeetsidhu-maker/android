package com.example.assngmnt3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import org.w3c.dom.Text;

public class DataBaseHelper extends SQLiteOpenHelper {
    public static final String dbName="Grade.db";
    public static final String Table_Name="Student";
    public static final String Col1="id";
    public static final String Col2="firstName";
    public static final String Col3="lastName";
    public static final String Col4="marks";
    public static final String Col5="course";
    public static final String Col6="credit";

    public static final String DROP_TABLE = " DROP TABLE IF EXISTS " + Table_Name;

    public static final String Create_Table = " create table " + Table_Name + "(" + Col1 + " INTEGER PRIMARY KEY AUTOINCREMENT ,"+Col2+" TEXT NOT NULL,"
            + Col3 +" TEXT,"+Col4 + " INTEGER," + Col5 + " TEXT, " + Col6 + " TEXT )";


    public DataBaseHelper(@Nullable Context context) {
        super(context, dbName,null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) { db.execSQL(Create_Table);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DROP_TABLE);
        onCreate(db);
    }
    public boolean insertGrade(Grade objgrade)
    {
        SQLiteDatabase db= this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put (Col2,objgrade.getFirstName());
        contentValues.put (Col3,objgrade.getLastName());
        contentValues.put (Col4,objgrade.getMarks());
        contentValues.put (Col5,objgrade.getCourse());
        contentValues.put (Col6,objgrade.getCredit());


        long res= db.insert(Table_Name,null,contentValues);

        if (res==-1){
            return false;
        }
        else {return true;}


    }
    public Cursor viewData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor;
        cursor = db.rawQuery("select * FROM "+   Table_Name,null);

        if (cursor !=null){
            cursor.moveToFirst();
        }
        return cursor;
    }

    public int updateGrade(Grade objGrade) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(Col2,objGrade.getFirstName());
        cv.put(Col3,objGrade.getLastName());
        cv.put(Col4,objGrade.getMarks());
        cv.put(Col5,objGrade.getCourse());
        cv.put(Col6,objGrade.getCredit());

        int numOfRow=db.update(Table_Name,cv,"id=" + objGrade.getStudentId(),null);
        return numOfRow;

    }

    public int deleteRecord(int id) {
        SQLiteDatabase db=this.getWritableDatabase();
        return db.delete(Table_Name,"id="+id,null);
    }
}
