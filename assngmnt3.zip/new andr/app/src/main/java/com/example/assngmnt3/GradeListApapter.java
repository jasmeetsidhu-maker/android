package com.example.assngmnt3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

class GradeListApapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private List<Grade> mList;
    public GradeListApapter(List<Grade> list, Context context) {
        super();
        mList= list;
    }
    class ViewHolder extends RecyclerView.ViewHolder{
        public TextView mTextId;
        public TextView mTextFirstName;
        public TextView mTextLastName;
        public TextView mTextMarks;
        public TextView mTextCourse;
        public TextView mTextCredit;



        public ImageView mPicture;
        public ViewHolder(View itemView){
            super(itemView);
            mTextId=(TextView) itemView.findViewById(R.id.txtID);
            mTextFirstName=(TextView) itemView.findViewById(R.id.txtFirstName);
            mTextLastName=(TextView) itemView.findViewById(R.id.txtLastName);
            mTextMarks=(TextView) itemView.findViewById(R.id.txtMarks);
            mTextCourse=(TextView) itemView.findViewById(R.id.txtCourse);
            mTextCredit=(TextView) itemView.findViewById(R.id.txtCredit);


        }

    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.record_layout,parent,false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder viewHolder, int position) {
        Grade gradeAdapter = mList.get(position);
        ((ViewHolder)viewHolder).mTextId.setText(Integer.toString(gradeAdapter.getStudentId()));
        ((ViewHolder)viewHolder).mTextFirstName.setText(gradeAdapter.getFirstName());
        ((ViewHolder)viewHolder).mTextLastName.setText(gradeAdapter.getLastName());
        ((ViewHolder)viewHolder).mTextMarks.setText(Integer.toString(gradeAdapter.getMarks()));



    }

    @Override
    public int getItemCount() {
        return mList.size();
    }
}
