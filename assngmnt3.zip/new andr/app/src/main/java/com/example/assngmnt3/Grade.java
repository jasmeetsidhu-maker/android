package com.example.assngmnt3;

class Grade {
    private int studentId;
    private String firstName;
    private String lastName;
    private Integer marks;
    private String course;
    private String credit;

    public Grade()
    {}

    public Grade(Integer id, String frstnam,String lstname,Integer mark, String course, String credit)
    {
        this.studentId=id;
        this.firstName=frstnam;
        this.lastName=lstname;
        this.marks=mark;
        this.course=course;
        this.credit=credit;
    }

    public void setStudentId(Integer id)
    {
        this.studentId=id;
    }
    public void setCourse(String course)
    {
        this.course=course;
    }public void setCredit(String credit)
    {
        this.credit=credit;
    }

    public void setFirstName(String frstnam)
    {
        this.firstName=frstnam;
    }
    public void setLastName(String lstname)
    {
        this.lastName=lstname;
    }
    public void setMarks(Integer mark)
    {
        this.marks=mark;
    }

    public int getStudentId()
    {
        return studentId;
    }
    public String  getFirstName()
    {
        return firstName;
    }
    public String  getCourse()
    {
        return course;
    }
    public String  getCredit()
    {
        return credit;
    }
    public String getLastName()
    {
        return lastName;
    }
    public Integer getMarks()
    {
        return marks;
    }
}
