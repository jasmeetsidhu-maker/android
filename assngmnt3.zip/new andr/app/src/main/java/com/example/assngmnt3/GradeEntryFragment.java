package com.example.assngmnt3;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.sql.DatabaseMetaData;


/**
 * A simple {@link Fragment} subclass.
 */
public class  GradeEntryFragment extends Fragment {

    EditText edtfirstName,edtlastName,edtmarks;

    RadioGroup credit;
    RadioButton one,two,three,four,selectedRadioButton;
    Button submit;
    DataBaseHelper dbh;
    Boolean insertGrade;
    ListView course;

     ArrayAdapter apdtCourse;
           String[] courseList= {"PROG 8480","PROG 8470","PROG 8460","PROG 8450"};
    String myCourse =" " ;

    public GradeEntryFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_grade_entry, container, false);
        //declare xml into java
        edtfirstName=v.findViewById(R.id.edtFirstName);
        edtlastName=v.findViewById(R.id.edtLastName);
        edtmarks=v.findViewById(R.id.edtMarks);
        course=v.findViewById(R.id.lvCourse);
        credit=v.findViewById(R.id.rgCredit);
        one=v.findViewById(R.id.rbOne);
        two=v.findViewById(R.id.rbTwo);
        three=v.findViewById(R.id.rbThree);
        four=v.findViewById(R.id.rbFour);
        submit=v.findViewById(R.id.btnSubmit);

        dbh = new DataBaseHelper(getActivity());

        apdtCourse=new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,courseList);
        course.setAdapter(apdtCourse);
        course.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {


            }
        });




        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int gradeID=0;
                String myCredit=" ";
                Grade stdnt=new Grade(gradeID,edtfirstName.getText().toString(),edtlastName.getText().toString(),Integer.parseInt((edtmarks.getText().toString())),course.toString(),myCredit);

                if(credit.getCheckedRadioButtonId()==-1)
                {
                    Toast.makeText(getActivity(), "Please select a credit", Toast.LENGTH_SHORT).show();
                }
                else {
                    int selectedId = credit.getCheckedRadioButtonId();
                    // find the radiobutton by returned id
                    selectedRadioButton = (RadioButton)v.findViewById(selectedId);
                    myCredit = selectedRadioButton.getText().toString();

                }

                insertGrade=dbh.insertGrade(stdnt);
                if (insertGrade){
                    Toast.makeText(getActivity(),"record added",Toast.LENGTH_SHORT).show();
                }
                else if ( !insertGrade){
                    Toast.makeText(getActivity(),"record not added",Toast.LENGTH_SHORT).show();

                }

            }
        });
        return v;


    }

}
